# 2026-11-05.1 · Initial Design System release

## 中文

- 新增五栏目中英文设计系统网站、组件/场景/规则搜索与响应式布局。
- 保留原有 88 个稳定登记 ID，补入 ImageInput、DurationInput 和 ContextualPolishActions，共 91 项。71 张既有设计预览保留来源；非交互条目明确标注证据边界。
- 七个真实共享组件接入 A2UI v0.9.1，官方 React / Web Core 固定 0.15.0。支持消息编辑、运行、逐步、数据/事件/校验、复制、重置与版本化下载。
- 图片示例展示确认后同步、失败重试和匹配移除；润色复用真实动作选择与参数保护，示例结果明确为模拟，包含选区、过期保护、无变化和撤销。
- 展示层统一 AgentImageInput，保留历史 photo 协议/存储身份。共享 SVG 支持 GitHub Pages 子路径。
- Notion 为规则唯一维护源；发布快照记录来源修订时间和哈希。手动 Actions 发布，保留源提交以回退。

验证：19 项网站契约测试、10 项相关产品回归测试、网站及产品构建；浏览器检查 1280px 桌面与 390px 手机、中英文、七个 Catalog 组件、搜索、数据绑定、事件、重试、无动作与参数保护。发布源另做无根目录依赖的独立构建检查。Claude CLI 只读审阅后的有效问题已修复。

边界：网站示例没有真实模型调用、设备连接、产品存储写入或实际任务提交。网站的模拟结果不证明原生适配器或真实设备验收。首次网站发布尚无上一线上版本；以后可从主分支历史中的发布提交重新运行同一工作流回退。

## English

- Adds bilingual Guides, Components, Scenarios, A2UI and Resources, searchable by purpose and responsive on mobile.
- Preserves 88 existing stable IDs and adds ImageInput, DurationInput and ContextualPolishActions: 91 entries, 71 sourced design previews. Noninteractive entries distinguish registry evidence from verified capabilities.
- Connects seven shared presentation components to A2UI v0.9.1 with official React / Web Core 0.15.0. Includes message editing, run/step, data/events/validation, copy/reset and versioned downloads.
- Image fixtures demonstrate confirmation-time sync, retry and matching removal. Polish reuses production action selection and parameter protection with explicitly simulated outcomes, selection, stale-result guards, unchanged output and undo.
- Renames the display implementation to AgentImageInput while preserving legacy photo identities. Shared SVG paths support the Pages project subpath.
- Notion remains the sole rule-authoring source. Snapshots carry revision/hash evidence. Publication is manual, with source-based rollback.

Validation: 19 website contract tests, 10 affected product regressions, website/product builds; desktop/mobile browser checks of bilingual navigation, seven Catalog components, search, binding, events, retry, empty actions and parameter protection. An independent source build checks that root dependencies are not required. Confirmed findings from a read-only Claude CLI review were fixed.

Limits: the website makes no real model calls, devices, product storage or task submissions. Fixtures do not establish native adapter or real-device acceptance. This is the first website release; subsequent releases can roll back by dispatching a previous release commit from main history.

## Post-publication correction · 2026-11-05

线上选区验证发现受控 textarea 回填会覆盖提前恢复的光标。现改为在 React 提交后恢复，浏览器实测光标停留在替换片段末尾（24），而不是全文末尾（36）；参数与撤销保持不变。规则版本不变，源码版本由 release.json 分别记录。上一发布提交 `0d9bdf0ee572489824b1db51c446a04462cf2945` 可供回退。

Live selection verification found that the controlled textarea commit overwrote early caret restoration. The preview now restores it after React commits. Browser readback verified offset 24 at the replacement boundary, instead of 36 at the full-text end. Parameters and undo remain intact. Rule version is unchanged; release.json records the separate source version. Previous release commit: `0d9bdf0ee572489824b1db51c446a04462cf2945`.

## Live component documentation · 2026-11-05

- 组件目录与详情取消截图展示，构建不再发布组件截图。优先浏览可交互条目；未接入独立示例的条目保留状态与 Figma／源码链接。
- 新增直接复用产品源码的弹性编辑区和句内参数编辑器，共 9 项真实示例；A2UI 仍为 7 项，单独标注，不把 React 展示误认为协议已接入。
- 详情顶部提供 Figma 来源和源码入口；图片输入链接到已登记图片选择节点。

Component screenshots are removed from the gallery, detail pages and build output. Nine entries now have real shared specimens, including the flexible composer and sentence parameter composer. Seven remain A2UI-enabled; React and A2UI availability are tracked independently. Figma and source links are accessible above each example.

## 2026-11-05.2 · Generative UI rules and task-to-control demo

中文：结合用户提供 PDF，向原 Notion 设计规范增加 GUI-01–08 与任务到界面的流程；网站发布双语快照，注明参考页码、项目适配及真实接入缺口。新增任务选控件演示，复用真实参数／润色规则，经模拟能力过滤后，显式选择入口生成固定模板和合法 A2UI。真实控件渲染，所有结果与状态只留本地；没有模型、设备或真实草稿写入。新增候选、能力、缺值、过期、手调保护与非法消息测试。退回上一发布可使用 5709d321586d231abedf1475a6098fa8b538e3d2 手动运行 Pages 工作流。

English: Added PDF-informed GUI-01–08 rules and the task-to-interface workflow to the canonical Notion page, then published bilingual excerpts with source pages, project adaptations and integration boundaries. The task demo reuses actual parameter/polish rules, filters against fictional capabilities and compiles an explicitly selected entry into a fixed template and validated A2UI. Shared controls run locally; no model, device or real draft is accessed. New tests cover candidates, capabilities, missing values, stale plans, manual parameters and invalid messages. Roll back by manually dispatching Pages against 5709d321586d231abedf1475a6098fa8b538e3d2.

## Unreleased · shared component extraction

- 从已提交原型提取 `packages/ui` 展示层；原产品路径保留兼容入口。设备、语音、存储、目标校验与同步仍由产品宿主管理。
- 96 个登记条目逐项核对：28 个独立共享示例、40 个共享控件内部状态/变体、7 个宿主场景组合、13 个未映射设计和 8 个历史/动效设计记录。未实现的设计不伪装成控件。
- 沙盒打开即显示，切换示例立即更新；JSON 校验成功后自动渲染，错误时停止预览。移除运行/逐步按钮，代码、数据与事件按需展开。
- 增加依赖方向检查、登记覆盖检查、桌面/手机真实组件交互测试；未新增 A2UI 执行权限。
- Ordinary verification: 37 site contracts, 231 core tests, product/site typecheck and builds, five site browser tests (including 28 specimens at desktop/mobile widths), five product extraction regressions. Product build retains its existing large-bundle advisory.
- One older offline-draft test fails identically at baseline `9772a5f` and after extraction: the controller unmounts on disconnection, while that test expects the draft to stay visible. This cleanup does not change offline behavior. Two stale test selectors were updated to the current baseline UI.
- Claude CLI read-only review reconciled against source. No merge, push, Pages deployment or device operation. Main contains unrelated uncommitted runtime changes: resolve those through a three-way merge, never replace main's controllers with this checkout.

## Independent input controls — 2026-11-16

Added 13 desktop React widgets with controlled props, semantic chip states, local assets, browser capture adapters and directly interactive examples. Text polishing is excluded from this new extraction; previous catalog and A2UI functionality remain available. No application caller or Xiaoyi Work deployment was changed. Source handoff and English setup guide live in `packages/input-controls/`.
