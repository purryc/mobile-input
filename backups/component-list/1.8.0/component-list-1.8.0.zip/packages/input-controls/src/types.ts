export const controlKinds = [
  "duration",
  "color",
  "font",
  "palette",
  "document",
  "photo",
  "scanner",
  "sketch",
  "expert",
  "skills",
  "connectors",
  "formats",
  "capture",
] as const;
export type WidgetKind = (typeof controlKinds)[number];
export type ControlOrigin = "explicit" | "recommended" | "manual";
export interface ChoiceBinding {
  id: string;
  kind: WidgetKind;
  origin: "explicit" | "recommended" | "manual";
  value: string[];
}
export interface ControlOption {
  id: string;
  zh: string;
  en: string;
  detail?: string;
  detailEn?: string;
  color?: string;
  swatches?: string[];
}
export interface ChoiceDefinition {
  kind: WidgetKind;
  zh: string;
  en: string;
  multiple?: boolean;
  demo?: boolean;
  options: ControlOption[];
}
export interface ChoiceEvent {
  type: "change" | "close" | "remove";
  owner: string;
  id: string;
  value?: string[];
}
export interface CaptureMaterial {
  id: string;
  kind: "scanner" | "screenshot" | "recording";
  /** For camera materials. Older scanner items represent document scans. */
  cameraMode?: "photo" | "scan";
  name: string;
  blob: Blob;
  size: number;
  duration?: number;
  confirmed: boolean;
}

export const widgetWidths: Record<WidgetKind, number> = {
  duration: 432,
  color: 320,
  font: 320,
  palette: 320,
  document: 320,
  photo: 320,
  scanner: 320,
  sketch: 320,
  expert: 432,
  skills: 432,
  connectors: 432,
  formats: 432,
  capture: 320,
};

export type ChipSemanticState =
  | "needs-input"
  | "default-selected"
  | "ambiguous-recommendation"
  | "object-bound";
